﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AngularwithASPCore.Models;

namespace AngularwithASPCore.DataAccess
{
    public interface IDataAccess
    {
        Task<List<Order>> GetAllRecords();
    }
}
