﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using filter_core.Models;
using Syncfusion.EJ2.Base;

namespace TestSample.Controllers
{

    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            data data = new data();
            data.orderData = data.GetAllRecords();
            data.columns = data.getGridColumns();
            //Syncfusion.EJ2.Grids.Grid gridProp = new Syncfusion.EJ2.Grids.Grid();
            //gridProp.AllowPaging = true;
            //gridProp.DataSource = order;
            //gridProp.EditSettings = new Syncfusion.EJ2.Grids.GridEditSettings() { AllowEditing = true, AllowDeleting = true, AllowAdding = true };
            
            //List<object> col = new List<object>();
            //gridProp.Toolbar = new List<string>() { "Add", "Edit", "Delete", "Update", "Cancel" };
            //col.Add(new { field = "OrderID", isPrimaryKey = true, headerText = "OrderID", width = "120" });
            //col.Add(new { field = "CustomerID", headerText = "CustomerID", width = "20", clipMode = Syncfusion.EJ2.Grids.ClipMode.EllipsisWithTooltip });
            //col.Add(new { field = "EmployeeID", headerText = "EmployeeID", width = "120" });
            //gridProp.Columns = col;
            //return View();


            //var Order = OrdersDetails.GetAllRecords();
            return View(data);
        }

        public IActionResult UrlDatasource([FromBody]Data dm)
        {
            //bind your data here
            var order = OrdersDetails.GetAllRecords();
            var Data = order.ToList();
            int count = order.Count();
            return dm.requiresCounts ? Json(new { result = Data.Skip(dm.skip).Take(dm.take), count = count }) : Json(Data);
        }

        public IActionResult childUrlDataSource([FromBody]extendDM dm) {
            
            List<OrdersDetails> DataDetails = new List<OrdersDetails>();        
        var ord = dm.@params["EmployeeID"];
            OrdersDetails val = OrdersDetails.GetAllRecords().Where(or => or.EmployeeID == ord).FirstOrDefault();
            DataDetails.Add(val);
            return dm.RequiresCounts ? Json(new { result = DataDetails, count = DataDetails.Count }) : Json(DataDetails);

        }


        public void UpdateDataSource([FromBody]CRUDData crudmodel) {
            if (crudmodel.action == "insert")
            {
                data dt = new data();
                dt.GetAllRecords().Insert(0, crudmodel.data);
            }
            else if (crudmodel.action == "save")
            {
                data dt = new data();
                var ord = crudmodel.data;
                filter_core.Models.OrderDetail val = dt.GetAllRecords().Where(or => or.OrderID == ord.OrderID).FirstOrDefault();
                val.OrderID = ord.OrderID;
                val.Verified = ord.Verified;
                val.EmployeeID = ord.EmployeeID;
                val.CustomerID = ord.CustomerID;
                val.Freight = ord.Freight;
                val.OrderDate = ord.OrderDate;
                val.ShipCity = ord.ShipCity;
            }
            else if (crudmodel.action == "delete") {
                data dt = new data();
                dt.GetAllRecords().Remove(dt.GetAllRecords().Where(or => or.OrderID == int.Parse(crudmodel.data.OrderID.ToString())).FirstOrDefault());
            }           
        }

        public ActionResult Update([FromBody]CRUDModel<OrdersDetails> value)
        {
            var ord = value.value;
            OrdersDetails val = OrdersDetails.GetAllRecords().Where(or => or.OrderID == ord.OrderID).FirstOrDefault();
            val.OrderID = ord.OrderID;
            val.Verified = ord.Verified;
            val.EmployeeID = ord.EmployeeID;
            val.CustomerID = ord.CustomerID;
            val.Freight = ord.Freight;
            val.OrderDate = ord.OrderDate;
            val.ShipCity = ord.ShipCity;

            return Json(value.value);
        }
        //insert the record
        public ActionResult Insert([FromBody]CRUDModel<OrdersDetails> value)
        {

            OrdersDetails.GetAllRecords().Insert(0, value.value);
            return Json(value.value);
        }
        //Delete the record
        public ActionResult CellEditDelete([FromBody]CRUDModel<OrdersDetails> value)
        {
            OrdersDetails.GetAllRecords().Remove(OrdersDetails.GetAllRecords().Where(or => or.OrderID == int.Parse(value.key.ToString())).FirstOrDefault());
            return Json(value);
        }

        public ActionResult GetData() {
            var data = OrdersDetails.GetAllRecords();
            return Json(data);

        }

        public class extendDM : DataManagerRequest {
            public Dictionary<string, int> @params { get; set; }
        }

        public class Data
        {

            public bool requiresCounts { get; set; }
            public int skip { get; set; }
            public int take { get; set; }
        }


        public class CRUDData {

            public string action { get; set; }
            public  filter_core.Models.OrderDetail data { get; set; }
        }


        public class CRUDModel<T> where T : class
        {
            public string action { get; set; }

            public string table { get; set; }

            public string keyColumn { get; set; }

            public object key { get; set; }

            public T value { get; set; }

            public List<T> added { get; set; }

            public List<T> changed { get; set; }

            public List<T> deleted { get; set; }

            public IDictionary<string, object> @params { get; set; }
        }
    }
    public class OrdersDetails
    {
        public static List<OrdersDetails> order = new List<OrdersDetails>();
        public OrdersDetails()
        {

        }
        public OrdersDetails(int OrderID, string CustomerId, int EmployeeId, double Freight, bool Verified, DateTime OrderDate, string ShipCity, string ShipName, string ShipCountry, DateTime ShippedDate, string ShipAddress)
        {
            this.OrderID = OrderID;
            this.CustomerID = CustomerId;
            this.EmployeeID = EmployeeId;
            this.Freight = Freight;
            this.ShipCity = ShipCity;
            this.Verified = Verified;
            this.OrderDate = OrderDate;
            this.ShipName = ShipName;
            this.ShipCountry = ShipCountry;
            this.ShippedDate = ShippedDate;
            this.ShipAddress = ShipAddress;
        }
        public static List<OrdersDetails> GetAllRecords()
        {
            if (order.Count() == 0)
            {
                int code = 10000;
                for (int i = 1; i < 10; i++)
                {
                    order.Add(new OrdersDetails(code + 1, "ALFKI", i + 0, 2.3 * i, false, new DateTime(1991, 05, 15), "Berlin", "Simons bistro", "Denmark", new DateTime(1996, 7, 16), "Kirchgasse 6"));
                    order.Add(new OrdersDetails(code + 2, "ANATR", i + 2, 3.3 * i, true, new DateTime(1990, 04, 04), "Madrid", "Queen Cozinha", "Brazil", new DateTime(1996, 9, 11), "Avda. Azteca 123"));
                    order.Add(new OrdersDetails(code + 3, "ANTON", i + 1, 4.3 * i, true, new DateTime(1957, 11, 30), "Cholchester", "Frankenversand", "Germany", new DateTime(1996, 10, 7), "Carrera 52 con Ave. Bolívar #65-98 Llano Largo"));
                    order.Add(new OrdersDetails(code + 4, "BLONP", i + 3, 5.3 * i, false, new DateTime(1930, 10, 22), "Marseille", "Ernst Handel", "Austria", new DateTime(1996, 12, 30), "Magazinweg 7"));
                    order.Add(new OrdersDetails(code + 5, "BOLID", i + 4, 6.3 * i, true, new DateTime(1953, 02, 18), "Tsawassen", "Hanari Carnes", "Switzerland", new DateTime(1997, 12, 3), "1029 - 12th Ave. S."));
                    code += 5;
                }
            }
            return order;
        }

        public int? OrderID { get; set; }
        public string CustomerID { get; set; }
        public int? EmployeeID { get; set; }
        public double? Freight { get; set; }
        public string ShipCity { get; set; }
        public bool Verified { get; set; }
        public DateTime OrderDate { get; set; }

        public string ShipName { get; set; }

        public string ShipCountry { get; set; }

        public DateTime ShippedDate { get; set; }
        public string ShipAddress { get; set; }
    }
}
