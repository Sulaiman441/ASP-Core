﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AngularwithASPCore.Models;
using Microsoft.Extensions.Primitives;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Web.Http;
using static TestSample.Controllers.HomeController;
using System.Dynamic;

namespace AngularwithASPCore.Controllers
{
    [Produces("application/json")]
    [Microsoft.AspNetCore.Mvc.Route("api/Orders")]
    
    public class OrdersController : Controller
    {
        // GET: api/Orders
        [Microsoft.AspNetCore.Mvc.HttpGet]

        public object Get()
        {

            var query = HttpContext.Request.Query;
                
            var data = OrdersDetails.GetAllRecords().ToList();

            return  new { Items = data, Count = data.Count() };
        }

        // GET: api/Orders/5
        [Microsoft.AspNetCore.Mvc.HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Orders
        [Microsoft.AspNetCore.Mvc.HttpPost]
        public object Post([Microsoft.AspNetCore.Mvc.FromBody]ExpandoObject value, [Microsoft.AspNetCore.Mvc.FromBody]OrdersDetails dt )
        {

            var dict = new Dictionary<string, object>(value);
            dynamic settings = new ExpandoObject();
            foreach (dynamic Dval in dict.Values)
            {
                if (((IDictionary<string, object>)Dval).ContainsKey("dataId"))
                {
                    foreach (var v in Dval)
                    {
                        if (v.Key != "update")
                        {
                            var fieldName = v.Key;
                            var newVal = v.Value;
                            // you can access your values 

                        }
                    }
                }
                else
                {
                    var ord = Dval;
                    OrdersDetails val = new OrdersDetails();
                    val.OrderID = ord.OrderID != null ? (int)ord.OrderID: ord;
                    val.EmployeeID = ord.EmployeeID != null ? (int)ord.EmployeeID: ord;                                       
                    val.OrderDate = ord.OrderDate != null ? ord.OrderDate: ord;
                    val.ShipCity = ord.ShipCity != null ? ord.ShipCity: ord;                   

                    OrdersDetails.GetAllRecords().Insert(0, val);
                    return ord;
                }

            }

            return Json(new { });
        }


        // PUT: api/Orders/5
        [Microsoft.AspNetCore.Mvc.HttpPut]
        public object Put([Microsoft.AspNetCore.Mvc.FromBody]ExpandoObject value, [Microsoft.AspNetCore.Mvc.FromBody]OrdersDetails data)
        {

            var dict = new Dictionary<string, object>(value);
            dynamic settings = new ExpandoObject();
            foreach (dynamic Dval in dict.Values)
            {
                if (((IDictionary<string, object>)Dval).ContainsKey("dataId"))
                {
                    foreach (var v in Dval)
                    {
                        if (v.Key != "update")
                        {
                            var fieldName = v.Key;
                            var newVal = v.Value;
                            // you can access your values 

                        }
                    }
                }
                else
                {
                    var ord = Dval;
                    OrdersDetails val = OrdersDetails.GetAllRecords().Where(or => or.OrderID == ord.OrderID).FirstOrDefault();
                    val.OrderID = (int)ord.OrderID;
                    val.EmployeeID = (int)ord.EmployeeID;
                    val.CustomerID = ord.CustomerID;
                    val.Freight = ord.Freight;
                    val.OrderDate = ord.OrderDate;
                    val.ShipCity = ord.ShipCity;
                    return ord;
                }

            }
            return Json(new { });
        }

        // DELETE: api/ApiWithActions/5
        //[Microsoft.AspNetCore.Mvc.HttpDelete("{id:int}")]
        //[Microsoft.AspNetCore.Mvc.Route("Orders/{id:int}")]
        public void Delete([Microsoft.AspNetCore.Mvc.FromBody]ExpandoObject value,int id)
        {
            var dict = new Dictionary<string, object>(value);
            ExpandoObject settings = new ExpandoObject();
            int number=0;
            foreach (dynamic Dval in dict.Values)
            {
                if ( Dval !=null && Dval.GetType() == settings.GetType())
                {
                    foreach (var v in Dval)
                    {
                        if (v.Key != "update")
                        {
                            var fieldName = v.Key;
                            var newVal = v.Value;
                            // you can access your values 
                        }
                    }
                }
                else if(Dval !=null && Dval.GetType() == Convert.ToInt64(number).GetType())
                {
                    var ord = Dval;
                    var data = OrdersDetails.GetAllRecords().Where(or => or.OrderID == ord).FirstOrDefault();
                    OrdersDetails.GetAllRecords().Remove(data);
                }

            }
            
        }

        
    }
    public class Data
    {
        public bool requiresCounts { get; set; }
        public int skip { get; set; }
        public int take { get; set; }
    }
}
