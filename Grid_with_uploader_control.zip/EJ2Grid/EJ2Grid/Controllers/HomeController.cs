﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EJ2Grid.Models;
using Syncfusion.EJ2.Base;
using System.Collections;
using System.IO;
using Microsoft.AspNetCore.Http;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Hosting;

namespace EJ2Grid.Controllers
{
    public class HomeController : Controller
    {
        public static List<Orders> order = new List<Orders>();
        public IActionResult Index()
        {
            if (order.Count == 0)
                BindDataSource();
            ViewBag.data = order;
            return View();
        }
        private void BindDataSource()
        {
            order.Add(new Orders(1, "", "", "", ""));
        }
        private IHostingEnvironment hostingEnv;
        public HomeController(IHostingEnvironment env)
        {
            this.hostingEnv = env;
        }
        [AcceptVerbs("Post")]
        public IActionResult Save(IList<IFormFile> UploadFiles)
        {
            long size = 0;
            try
            {
                foreach (var file in UploadFiles)
                {
                    var filename = ContentDispositionHeaderValue
                                    .Parse(file.ContentDisposition)
                                    .FileName
                                    .Trim('"');
                    var folders = filename.Split('/');
                    var uploaderFilePath = @".\Copied files"; // Provide the file pasting path details
                    // for Directory upload
                    if (folders.Length > 1)
                    {
                        for (var i = 0; i < folders.Length - 1; i++)
                        {
                            var newFolder = uploaderFilePath + $@"\{folders[i]}";
                            Directory.CreateDirectory(newFolder);
                            uploaderFilePath = newFolder;
                            filename = folders[i + 1];
                        }
                    }
                    size += file.Length;
                   
                    filename = uploaderFilePath + $@"\{filename}";
                    if (!System.IO.File.Exists(filename))
                    {
                        using (FileStream fs = System.IO.File.Create(filename))
                        {
                            string receivedPath = Path.GetFullPath(filename); // get the file pasted path details
                            receivedPath = receivedPath + ":end";
                            Response.HttpContext.Features.Get<IHttpResponseFeature>().ReasonPhrase = fs.ToString();
                            Response.HttpContext.Features.Get<IHttpResponseFeature>().Headers.Add("Path", receivedPath); // send the path details to client through the headers
                            file.CopyTo(fs); // Copy the file to mentioned path
                            fs.Flush();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Response.Clear();
                Response.ContentType = "application/json; charset=utf-8";
                Response.StatusCode = 204;
                Response.HttpContext.Features.Get<IHttpResponseFeature>().ReasonPhrase = "No Content";
                Response.HttpContext.Features.Get<IHttpResponseFeature>().ReasonPhrase = e.Message;
            }
            return Content("");
        }
        public class Orders
        {
            public Orders()
            {

            }
            public Orders(long OrderId, string DocumentName, string Status, string CurrentPath, string CopiedPath)
            {
                this.OrderID = OrderId;
                this.DocumentName = DocumentName;
                this.Status = Status;
                this.CurrentPath = CurrentPath;
                this.CopiedPath = CopiedPath;
            }
            public long OrderID { get; set; }
            public string DocumentName { get; set; }
            public string Status { get; set; }
            public string CurrentPath { get; set; }
            public string CopiedPath { get; set; }
        }
    }
}
